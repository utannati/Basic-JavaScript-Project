var name = "JavaScript!";
alert(name)

function displayDate() {
document.getElementById("text").innerHTML = Date();
}


function myFunction() {
    var sentence = "I am learning";
    sentence += "a lot from this course!";
    document.getElementById("concatenate").innerHTML = sentence();
}